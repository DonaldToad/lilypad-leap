// app/lib/addresses.ts
export const DTC_BY_CHAIN: Record<number, `0x${string}`> = {
  // Linea
  59144: "0xEb1fD1dBB8aDDA4fa2b5A5C4bcE34F6F20d125D2",
  // Base
  8453: "0xFbA669C72b588439B29F050b93500D8b645F9354",
};

export const LILYPAD_VAULT_BY_CHAIN: Record<number, `0x${string}`> = {
  // Linea
  59144: "0x6AA5DE9E477CFa0994037fB0aF116775778f447b",
  // Base
  8453: "0x49F2BF35e7249E6c7a991fb70d21EF215A67F8F5",
};
